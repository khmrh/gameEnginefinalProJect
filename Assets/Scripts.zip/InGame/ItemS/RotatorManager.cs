using UnityEngine;
using System.Collections.Generic;

public class RotatorManager : MonoBehaviour
{
    [Header("ȸ�� ������ ����")]
    public GameObject rotatorPrefab;
    public float radius = 1.5f;
    public float rotationSpeed = 180f;

    private List<GameObject> rotators = new List<GameObject>();
    private int currentLevel = 0;

    private void Update()
    {
        if (rotators.Count == 0) return;

        float angleStep = 360f / rotators.Count;

        for (int i = 0; i < rotators.Count; i++)
        {
            float angle = Time.time * rotationSpeed + angleStep * i;
            Vector3 offset = new Vector3(Mathf.Cos(angle * Mathf.Deg2Rad), Mathf.Sin(angle * Mathf.Deg2Rad)) * radius;

            if (rotators[i] != null)
            {
                rotators[i].transform.localPosition = offset;
            }
        }
    }

    public void SetLevel(int level)
    {
        if (level == currentLevel) return;
        currentLevel = level;
        UpdateRotators();
    }

    private void UpdateRotators()
    {
        // ���� ȸ��ü ����
        foreach (Transform child in transform)
        {
            Destroy(child.gameObject);
        }

        rotators.Clear();

        float angleStep = 360f / currentLevel;

        for (int i = 0; i < currentLevel; i++)
        {
            GameObject instance = Instantiate(rotatorPrefab);  //�θ� ���� ����
            instance.transform.SetParent(transform);            //�θ�� ���߿� ����
            instance.transform.localRotation = Quaternion.identity;

            float angle = angleStep * i;
            Vector3 offset = new Vector3(Mathf.Cos(angle * Mathf.Deg2Rad), Mathf.Sin(angle * Mathf.Deg2Rad)) * radius;
            instance.transform.localPosition = offset;

            rotators.Add(instance);
        }
    }
}
